package mx.autolauncher

import android.content.Context
import android.content.Intent
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap, val intent: Intent)

suspend fun loadApps(ctx: Context): List<AppInfo> = withContext(Dispatchers.IO) {
    val pm = ctx.packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    pm.queryIntentActivities(q, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map {
            val pkg = it.activityInfo.packageName
            AppInfo(
                label = it.loadLabel(pm).toString(),
                pkg = pkg,
                icon = it.loadIcon(pm).toBitmap(128, 128).asImageBitmap(),
                intent = pm.getLaunchIntentForPackage(pkg) ?: Intent()
            )
        }
        .sortedBy { it.label.lowercase() }
}
