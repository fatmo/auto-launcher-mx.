package mx.autolauncher

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Amber: Color get() = if (Cfg.themeIdx == 1) Color(0xFFFF6A00) else Color(0xFFFFB020)

@Composable
fun MxCard(u: Dp, modifier: Modifier = Modifier, edge: Color = Mx.Line, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(u * 2.8f)
    Column(modifier.clip(shape).background(Mx.Panel).border(1.dp, edge, shape).padding(u * 2f), content = content)
}

@Composable
fun Txt(s: String, u: Dp, k: Float, color: Color = Mx.Text, bold: Boolean = false, mono: Boolean = false) =
    Text(s, color = color, fontSize = (u.value * k).sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        fontFamily = if (mono) Mx.Tech else FontFamily.Default)

@Composable
fun CircleBtn(size: Dp, bg: Color, onClick: () -> Unit, content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.size(size).clip(CircleShape).background(bg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center, content = content)
}
