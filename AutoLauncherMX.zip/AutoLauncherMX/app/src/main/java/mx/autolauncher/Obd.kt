package mx.autolauncher

import android.bluetooth.BluetoothAdapter
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.UUID

/** Lectura de datos del auto con un adaptador ELM327 (Bluetooth clásico o WiFi). */
object Obd {
    var status by mutableStateOf("Elige tu adaptador")
    var connected by mutableStateOf(false)
    var rpm by mutableStateOf<Int?>(null)
    var speed by mutableStateOf<Int?>(null)
    var coolant by mutableStateOf<Int?>(null)
    var volts by mutableStateOf<Double?>(null)
    var fuelPct by mutableStateOf<Int?>(null)
    var lph by mutableStateOf<Double?>(null)        // litros por hora (consumo del motor)
    var instKmL by mutableStateOf<Double?>(null)    // km/L al instante (solo en movimiento)
    var tripKmL by mutableStateOf<Double?>(null)    // km/L promedio desde que se conectó
    var dtcs by mutableStateOf<List<String>>(emptyList())
    var dtcMsg by mutableStateOf("")
    @Volatile var pending: String? = null           // "03" leer fallas, "04" borrar fallas

    private var started = false
    private val SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private class Link(val i: InputStream, val o: OutputStream, val close: () -> Unit)

    fun start(ctx: Context) {
        if (started) return
        started = true
        val app = ctx.applicationContext
        Thread { loop(app) }.apply { isDaemon = true; start() }
    }

    private fun clearLive() {
        connected = false; rpm = null; speed = null; coolant = null; volts = null
        fuelPct = null; lph = null; instKmL = null
    }

    private fun loop(ctx: Context) {
        while (true) {
            if (Cfg.obdMac.isEmpty() || !Cfg.obdOn) {
                clearLive(); status = if (Cfg.obdMac.isEmpty()) "Elige tu adaptador" else "Desactivado"
                Thread.sleep(3000); continue
            }
            var link: Link? = null
            try {
                status = "Conectando…"
                link = open()
                for (c in listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0")) send(link, c, if (c == "ATZ") 4000 else 2000)
                status = "Buscando protocolo…"
                if (!send(link, "0100", 12000).contains("4100")) {
                    status = "Adaptador listo, pero el auto no responde (¿está encendido?)"
                    throw IOException("sin respuesta del auto")
                }
                status = "Conectado"; connected = true
                poll(link)
            } catch (e: Exception) {
                clearLive()
                if (status == "Conectado" || status == "Conectando…") status = "Sin conexión, reintentando…"
            } finally {
                try { link?.close?.invoke() } catch (e: Exception) {}
            }
            Thread.sleep(5000)
        }
    }

    private fun open(): Link {
        if (Cfg.obdMac == "WIFI") {
            val s = Socket()
            s.connect(InetSocketAddress("192.168.0.10", 35000), 6000)
            return Link(s.getInputStream(), s.getOutputStream()) { s.close() }
        }
        val ad = BluetoothAdapter.getDefaultAdapter() ?: throw IOException("Sin Bluetooth")
        val dev = ad.getRemoteDevice(Cfg.obdMac)
        try { ad.cancelDiscovery() } catch (e: Exception) {}
        val sock = try {
            dev.createRfcommSocketToServiceRecord(SPP).also { it.connect() }
        } catch (e: Exception) {
            dev.createInsecureRfcommSocketToServiceRecord(SPP).also { it.connect() }
        }
        return Link(sock.inputStream, sock.outputStream) { sock.close() }
    }

    private fun send(l: Link, cmd: String, timeout: Int = 2500): String {
        l.o.write((cmd + "\r").toByteArray()); l.o.flush()
        val sb = StringBuilder()
        val end = System.currentTimeMillis() + timeout
        while (System.currentTimeMillis() < end) {
            while (l.i.available() > 0) {
                val b = l.i.read()
                if (b == '>'.code) return clean(sb.toString())
                sb.append(b.toChar())
            }
            Thread.sleep(15)
        }
        return clean(sb.toString())
    }

    private fun clean(s: String) = s.uppercase().replace(Regex("\\s"), "").replace("SEARCHING...", "")

    private fun poll(l: Link) {
        val fails = HashMap<String, Int>()
        var silent = 0
        val lvl = ArrayDeque<Int>()
        var tripKm = 0.0; var tripL = 0.0
        var last = System.currentTimeMillis()

        fun q(pid: String): List<Int>? {
            if ((fails[pid] ?: 0) >= 3) return null            // el auto no soporta este dato
            val r = send(l, "01$pid")
            val k = r.indexOf("41$pid")
            if (k < 0) { fails[pid] = (fails[pid] ?: 0) + 1; return null }
            fails[pid] = 0
            return r.substring(k + 4).chunked(2).filter { it.length == 2 }.mapNotNull { it.toIntOrNull(16) }
        }

        while (Cfg.obdOn && Cfg.obdMac.isNotEmpty()) {
            pending?.let { cmd ->
                pending = null
                val r = send(l, cmd, 6000)
                if (cmd == "03") { dtcs = parseDtc(r); dtcMsg = if (dtcs.isEmpty()) "Sin fallas guardadas" else dtcs.joinToString("  ") }
                else dtcMsg = "Fallas borradas"
            }
            val r = q("0C")
            if (r == null || r.size < 2) { if (++silent >= 6) throw IOException("conexión perdida") } else silent = 0
            rpm = r?.takeIf { it.size >= 2 }?.let { (it[0] * 256 + it[1]) / 4 }
            speed = q("0D")?.getOrNull(0)
            coolant = q("05")?.getOrNull(0)?.minus(40)
            fuelPct = q("2F")?.getOrNull(0)?.let { it * 100 / 255 }
            fuelPct?.let { p ->            // mediana de las últimas lecturas: el nivel se mueve con las curvas
                lvl.addLast(p); if (lvl.size > 7) lvl.removeFirst()
                if (lvl.size >= 5) trackFuel(lvl.sorted()[lvl.size / 2])
            }
            volts = Regex("([0-9]+\\.?[0-9]*)V").find(send(l, "ATRV"))?.groupValues?.get(1)?.toDoubleOrNull()

            // Consumo del motor: 1) tasa de combustible, 2) flujo de aire (MAF), 3) estimación por presión (MAP)
            val rate = q("5E")?.takeIf { it.size >= 2 }?.let { (it[0] * 256 + it[1]) / 20.0 }
            var lh = rate
            if (lh == null) {
                var maf = q("10")?.takeIf { it.size >= 2 }?.let { (it[0] * 256 + it[1]) / 100.0 }
                if (maf == null) {
                    val map = q("0B")?.getOrNull(0); val iat = q("0F")?.getOrNull(0)
                    val n = rpm
                    if (map != null && iat != null && n != null)
                        maf = (n / 120.0) * 0.8 * Cfg.engineL * map / (0.287 * (iat - 40 + 273.15))
                }
                if (maf != null) lh = maf * 3600.0 / (14.7 * 745.0)
            }
            lph = lh
            val v = speed
            instKmL = if (v != null && lh != null && v >= 5 && lh > 0.05) v / lh else null

            val now = System.currentTimeMillis()
            val hrs = (now - last) / 3_600_000.0; last = now
            if (lh != null) tripL += lh * hrs
            if (v != null) tripKm += v * hrs
            tripKmL = if (tripL > 0.05) tripKm / tripL else null
        }
    }

    /** Detecta llenados por el salto del nivel y calcula km/L del tramo con la capacidad del tanque. */
    private fun trackFuel(p: Int) {
        if (Cfg.segPct < 0) {
            Cfg.segPct = p.toDouble(); Cfg.segLow = p.toDouble(); Cfg.segKm = Trip.totalKm
            if (Cfg.fuelBase < 0) Cfg.fuelBase = Trip.totalKm
            Cfg.save(); return
        }
        if (p < Cfg.segLow) { Cfg.segLow = p.toDouble(); Cfg.save(); return }
        if (p - Cfg.segLow >= 15) {                       // subió 15 puntos o más = se cargó gasolina
            val used = (Cfg.segPct - Cfg.segLow) * Cfg.tankL / 100.0
            val km = Trip.totalKm - Cfg.segKm
            if (used >= 5 && km >= 20) { Cfg.lastKmL = km / used; Cfg.fuelKm += km; Cfg.fuelL += used }
            Cfg.fuelBase = Trip.totalKm
            Cfg.segPct = p.toDouble(); Cfg.segLow = p.toDouble(); Cfg.segKm = Trip.totalKm
            Cfg.save()
        }
    }

    private fun parseDtc(resp: String): List<String> {
        val i = resp.indexOf("43"); if (i < 0) return emptyList()
        var h = resp.substring(i + 2).filter { it in "0123456789ABCDEF" }
        if (h.length % 4 == 2) h = h.substring(2)                 // protocolo CAN: primer byte = cantidad
        return h.chunked(4).filter { it.length == 4 && it != "0000" }.map {
            val b = it.toInt(16)
            "PCBU"[(b shr 14) and 3].toString() + ((b shr 12) and 3) + "%03X".format(b and 0xFFF)
        }
    }
}
