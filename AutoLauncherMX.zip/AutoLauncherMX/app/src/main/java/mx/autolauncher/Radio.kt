package mx.autolauncher

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.MediaPlayer
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class Station(val name: String, val url: String)

fun parseStations(text: String): List<Station> = text.lines().mapNotNull { line ->
    val i = line.indexOf('|')
    if (i <= 0) null else {
        val n = line.substring(0, i).trim(); val u = line.substring(i + 1).trim()
        if (n.isNotEmpty() && u.startsWith("http")) Station(n, u) else null
    }
}

/** Reproductor de radio por internet. Sigue sonando al salir de la pantalla de radios. */
object Radio {
    var current by mutableStateOf<String?>(null)
    var status by mutableStateOf("")
    private var mp: MediaPlayer? = null
    private var session: MediaSession? = null
    private val focus = AudioManager.OnAudioFocusChangeListener { f ->
        when (f) {
            AudioManager.AUDIOFOCUS_LOSS -> stop()
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> mp?.pause()
            AudioManager.AUDIOFOCUS_GAIN -> mp?.start()
        }
    }

    fun play(ctx: Context, name: String, url: String) {
        val app = ctx.applicationContext
        stop()
        current = name; status = "Conectando…"
        @Suppress("DEPRECATION")
        (app.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
            .requestAudioFocus(focus, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        try {
            val p = MediaPlayer()
            p.setAudioAttributes(AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
            p.setWakeMode(app, PowerManager.PARTIAL_WAKE_LOCK)
            p.setOnPreparedListener { it.start(); status = "En vivo"; publish(name, true) }
            p.setOnErrorListener { _, _, _ -> status = "No se pudo reproducir (revisa el link)"; publish(name, false); true }
            p.setDataSource(url)
            p.prepareAsync()
            mp = p
            val s = MediaSession(app, "MxRadio")
            s.setCallback(object : MediaSession.Callback() {
                override fun onPlay() { mp?.start(); publish(name, true) }
                override fun onPause() { mp?.pause(); publish(name, false) }
                override fun onStop() { stop() }
            })
            s.isActive = true
            session = s
            publish(name, false)
        } catch (e: Exception) { status = "Error: ${e.message ?: "link no válido"}" }
    }

    private fun publish(name: String, playing: Boolean) {
        val s = session ?: return
        s.setMetadata(MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, name)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, "Radio en vivo").build())
        s.setPlaybackState(PlaybackState.Builder()
            .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_STOP)
            .setState(if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, 0L, 1f).build())
    }

    fun stop() {
        try { mp?.release() } catch (e: Exception) {}
        mp = null
        try { session?.isActive = false; session?.release() } catch (e: Exception) {}
        session = null
        current = null; status = ""
    }
}
