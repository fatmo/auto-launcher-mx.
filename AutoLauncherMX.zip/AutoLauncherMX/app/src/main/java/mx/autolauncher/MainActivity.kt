package mx.autolauncher

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.provider.Settings
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { startTrip() }

    private fun startTrip() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            try { ContextCompat.startForegroundService(this, Intent(this, TripService::class.java)) } catch (e: Exception) {}
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        Trip.init(this)
        val need = buildList {
            add(Manifest.permission.ACCESS_FINE_LOCATION); add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (need.isEmpty()) startTrip() else permLauncher.launch(need.toTypedArray())
        setContent { LauncherTheme { LauncherRoot() } }
    }
}

enum class Screen { HOME, APPS, SETTINGS, MAP, RADIO, YOUTUBE }

@Composable
fun LauncherRoot() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    BackHandler(true) { screen = Screen.HOME } // un launcher nunca se cierra con "atrás"

    BoxWithConstraints(Modifier.fillMaxSize().background(Mx.Bg)) {
        // Unidad adaptable: equivale a "1vh" (o 0.62vw en pantallas muy estrechas)
        val u: Dp = (minOf(maxHeight.value, maxWidth.value * 0.62f) / 100f).dp
        val aspect = maxWidth / maxHeight
        when {
            screen == Screen.SETTINGS -> SettingsPanel(u) { screen = Screen.HOME }
            screen == Screen.APPS -> AppDrawer(u) { screen = Screen.HOME }
            screen == Screen.MAP -> MapScreen(u) { screen = Screen.HOME }
            screen == Screen.RADIO -> RadioScreen(u) { screen = Screen.HOME }
            screen == Screen.YOUTUBE -> YouTubeScreen(u) { screen = Screen.HOME }
            else -> Home(u, aspect) { screen = it }
        }
    }
}

@Composable
private fun SettingsPanel(u: Dp, close: () -> Unit) {
    var name by remember { mutableStateOf(Cfg.carName) }
    var model by remember { mutableStateOf(Cfg.carModel) }
    var interval by remember { mutableStateOf(Cfg.oilInterval.toString()) }
    var since by remember { mutableStateOf(maxOf(0.0, Trip.totalKm - Cfg.lastOilKm).toInt().toString()) }
    var auto by remember { mutableStateOf(Cfg.autoPlay) }
    var liters by remember { mutableStateOf("") }
    var engine by remember { mutableStateOf(Cfg.engineL.toString()) }
    var owner by remember { mutableStateOf(Cfg.ownerName) }
    var year by remember { mutableStateOf(Cfg.carYear) }
    val pick = rememberPhotoPicker()
    var tank by remember { mutableStateOf(Cfg.tankL.toString()) }
    val ctx = LocalContext.current
    var fuelMsg by remember { mutableStateOf("") }
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(u * 2),
        verticalArrangement = Arrangement.spacedBy(u * 1.5f)) {
        Txt("Tema de colores", u, 3.2f, bold = true)
        Row(horizontalArrangement = Arrangement.spacedBy(u * 1.5f)) {
            Accents.forEachIndexed { i, t ->
                val sel = Cfg.themeIdx == i
                Row(Modifier.weight(1f).height(maxOf(52.dp, u * 10)).clip(RoundedCornerShape(u * 2.6f)).background(Mx.Panel2)
                    .border(if (sel) 3.dp else 1.dp, if (sel) t.main else Mx.Line, RoundedCornerShape(u * 2.6f))
                    .clickable { Cfg.themeIdx = i; Cfg.save() },
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    Box(Modifier.size(u * 3.4f).clip(RoundedCornerShape(50)).background(t.main))
                    Spacer(Modifier.width(u))
                    Txt(t.name, u, 2.8f, Mx.Text, bold = sel)
                }
            }
        }
        Txt("Mi vehículo", u, 4f, bold = true)
        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Nombre (ej. Mi Aveo)") }, singleLine = true)
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Modelo") }, singleLine = true)
        OutlinedTextField(year, { year = it.filter(Char::isDigit).take(4) }, Modifier.fillMaxWidth(), label = { Text("Año") },
            singleLine = true, keyboardOptions = num)
        OutlinedTextField(owner, { owner = it }, Modifier.fillMaxWidth(), label = { Text("Tu nombre (saludo)") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(u * 2)) {
            DockButton("Elegir foto del auto", u, Modifier.weight(1f)) { pick() }
            DockButton("Usar foto original", u, Modifier.weight(1f)) { Cfg.carPhoto = ""; Cfg.save() }
        }
        OutlinedTextField(interval, { interval = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(),
            label = { Text("Cambio de aceite cada (km)") }, singleLine = true, keyboardOptions = num)
        OutlinedTextField(since, { since = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(),
            label = { Text("Km recorridos desde el último cambio") }, singleLine = true, keyboardOptions = num)
        Txt("Scanner OBD2 (ELM327)", u, 3.2f, bold = true)
        Text("1) Empareja el ELM327 en los ajustes Bluetooth de la pantalla (PIN 1234 o 0000). 2) Elígelo aquí. 3) Enciende el auto.",
            color = Mx.Mute, fontSize = (u.value * 2f).sp)
        Txt("Estado: ${Obd.status}", u, 2.4f, if (Obd.connected) Mx.Blue2 else Mx.Text)
        if (Cfg.obdMac.isNotEmpty()) Txt("Seleccionado: ${Cfg.obdName.ifEmpty { Cfg.obdMac }}", u, 2.4f, Mx.Mute)
        val bonded = remember {
            try { BluetoothAdapter.getDefaultAdapter()?.bondedDevices?.map { (it.name ?: it.address) to it.address } ?: emptyList() }
            catch (e: Exception) { emptyList() }
        }
        bonded.forEach { (n, mac) ->
            DockButton(n, u, Modifier.fillMaxWidth()) { Cfg.obdMac = mac; Cfg.obdName = n; Cfg.obdOn = true; Cfg.save() }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(u * 2)) {
            DockButton("Ajustes Bluetooth", u, Modifier.weight(1f)) { Actions.launch(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
            DockButton("Usar OBD WiFi", u, Modifier.weight(1f)) { Cfg.obdMac = "WIFI"; Cfg.obdName = "OBD WiFi"; Cfg.obdOn = true; Cfg.save() }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(u * 2)) {
            DockButton("Leer fallas", u, Modifier.weight(1f)) { Obd.pending = "03" }
            DockButton("Borrar fallas", u, Modifier.weight(1f)) { Obd.pending = "04" }
            DockButton(if (Cfg.obdOn) "Desactivar OBD" else "Activar OBD", u, Modifier.weight(1f)) { Cfg.obdOn = !Cfg.obdOn; Cfg.save() }
        }
        if (Obd.dtcMsg.isNotEmpty()) Text(Obd.dtcMsg, color = Mx.Blue2, fontSize = (u.value * 2.4f).sp)
        OutlinedTextField(tank, { tank = it.filter { c -> c.isDigit() || c == '.' } }, Modifier.fillMaxWidth(),
            label = { Text("Capacidad del tanque (litros)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        OutlinedTextField(engine, { engine = it.filter { c -> c.isDigit() || c == '.' } }, Modifier.fillMaxWidth(),
            label = { Text("Motor en litros (Aveo 1.6 = 1.6) · solo si tu auto no da consumo directo") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        Txt("Rendimiento (km/L)", u, 3.2f, bold = true)
        Text("Llena el tanque hasta el tope, escribe los litros y registra. El rendimiento se calcula entre un llenado y el siguiente.", color = Mx.Mute, fontSize = (u.value * 2f).sp)
        OutlinedTextField(liters, { liters = it.filter { c -> c.isDigit() || c == '.' } }, Modifier.fillMaxWidth(),
            label = { Text("Litros cargados (tanque lleno)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        DockButton("Registrar tanque lleno", u, Modifier.fillMaxWidth()) {
            val l = liters.toDoubleOrNull() ?: 0.0
            if (l > 0) {
                val first = Cfg.fuelBase < 0
                Cfg.registerFill(l, Trip.totalKm)
                fuelMsg = if (first) "Listo: punto de partida guardado. Con el próximo llenado verás km/L."
                          else "Último: ${"%.1f".format(Cfg.lastKmL)} km/L · Promedio: ${"%.1f".format(Cfg.avgKmL)} km/L"
                liters = ""
            }
        }
        if (fuelMsg.isNotEmpty()) Text(fuelMsg, color = Mx.Blue2, fontSize = (u.value * 2.2f).sp)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(u * 2)) {
            Switch(auto, { auto = it })
            Txt("Reproducir música al conectar Bluetooth / encender", u, 2.6f)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(u * 2)) {
            DockButton("Aceite cambiado hoy", u, Modifier.weight(1f)) { since = "0" }
            DockButton("Guardar", u, Modifier.weight(1f)) {
                Cfg.carName = name; Cfg.carModel = model; Cfg.carYear = year; Cfg.ownerName = owner
                Cfg.oilInterval = interval.toIntOrNull()?.coerceAtLeast(1) ?: 5000
                Cfg.lastOilKm = Trip.totalKm - (since.toDoubleOrNull() ?: 0.0)
                Cfg.autoPlay = auto
                Cfg.tankL = tank.toDoubleOrNull()?.coerceIn(10.0, 200.0) ?: 45.0
                Cfg.engineL = engine.toDoubleOrNull()?.coerceIn(0.6, 8.0) ?: 1.6
                Cfg.save(); close()
            }
        }
        DockButton("◀  Volver sin guardar", u, Modifier.fillMaxWidth(), close)
    }
}

@Composable
fun DockButton(label: String, u: Dp, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.height(maxOf(52.dp, u * 10)).clip(RoundedCornerShape(u * 2.6f)).background(Mx.Panel2)
        .clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = Mx.Text, fontFamily = Mx.Tech, fontSize = (u.value * 3f).sp, maxLines = 1)
    }
}

@Composable
private fun AppDrawer(u: Dp, close: () -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    LaunchedEffect(Unit) { apps = loadApps(ctx) }
    Column(Modifier.fillMaxSize().padding(u * 2), verticalArrangement = Arrangement.spacedBy(u * 2)) {
        DockButton("◀  Inicio", u, Modifier.width(u * 30), close)
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = maxOf(96.dp, u * 20)),
            horizontalArrangement = Arrangement.spacedBy(u * 2), verticalArrangement = Arrangement.spacedBy(u * 2)
        ) {
            items(apps, key = { it.pkg }) { a ->
                Column(
                    Modifier.clip(RoundedCornerShape(u * 2.5f)).background(Mx.Panel)
                        .clickable { Actions.launch(ctx, a.intent) }.padding(u * 1.5f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(a.icon, a.label, Modifier.size(u * 11))
                    Text(a.label, color = Mx.Text, fontSize = (u.value * 2.4f).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}
