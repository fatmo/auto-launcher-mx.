package mx.autolauncher

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.location.Location
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Ajustes del usuario (guardados en el equipo). */
object Cfg {
    lateinit var sp: SharedPreferences
    private var ready = false
    var carName by mutableStateOf("Mi Aveo")
    var carModel by mutableStateOf("Chevrolet Aveo")
    var carYear by mutableStateOf("2014")
    var themeIdx by mutableStateOf(3)      // 0 rojo, 1 amarillo, 2 verde, 3 azul
    var ownerName by mutableStateOf("")
    var btPackage by mutableStateOf("")    // app de Bluetooth/música BT propia de la pantalla
    var autoOpen by mutableStateOf(true)   // abrir el launcher al encender el equipo
    var aaPackage by mutableStateOf("")    // app receptora de Android Auto (vacío = detectar gb.xxy.hr / gb.xxy.trial)
    var carPhoto by mutableStateOf("")     // foto propia del auto (uri); vacío = dibujo del Aveo gris
    var oilInterval by mutableStateOf(5000)
    var lastOilKm by mutableStateOf(0.0)
    var autoPlay by mutableStateOf(true)
    // Rendimiento: método "tanque lleno a tanque lleno"
    var fuelBase by mutableStateOf(-1.0)   // odómetro GPS en el último llenado (-1 = sin registro)
    var fuelKm by mutableStateOf(0.0)
    var fuelL by mutableStateOf(0.0)
    var lastKmL by mutableStateOf(0.0)
    // Scanner OBD2
    var obdMac by mutableStateOf("")      // dirección Bluetooth o "WIFI"
    var obdName by mutableStateOf("")
    var obdOn by mutableStateOf(true)
    var radios by mutableStateOf("")      // una estación por línea: Nombre|URL
    var tankL by mutableStateOf(45.0)     // capacidad del tanque (litros)
    var segPct by mutableStateOf(-1.0)    // seguimiento automático de llenados con el nivel OBD
    var segLow by mutableStateOf(-1.0)
    var segKm by mutableStateOf(0.0)
    var engineL by mutableStateOf(1.6)    // cilindrada del motor (litros), para estimar consumo

    val avgKmL: Double get() = if (fuelL > 0) fuelKm / fuelL else 0.0

    /** Llama esto al llenar el tanque por completo con [liters] litros. */
    fun registerFill(liters: Double, odo: Double) {
        if (fuelBase >= 0 && liters > 0) {
            val km = odo - fuelBase
            if (km > 1) { lastKmL = km / liters; fuelKm += km; fuelL += liters }
        }
        fuelBase = odo
        save()
    }

    fun init(ctx: Context) {
        if (ready) return
        sp = ctx.applicationContext.getSharedPreferences("mx", Context.MODE_PRIVATE)
        carName = sp.getString("carName", carName)!!
        carModel = sp.getString("carModel", carModel)!!
        carYear = sp.getString("carYear", carYear)!!
        themeIdx = sp.getInt("themeIdx", 3)
        ownerName = sp.getString("ownerName", "")!!
        aaPackage = sp.getString("aaPackage", "")!!
        btPackage = sp.getString("btPackage", "")!!
        autoOpen = sp.getBoolean("autoOpen", true)
        carPhoto = sp.getString("carPhoto", "")!!
        oilInterval = sp.getInt("oilInterval", oilInterval)
        lastOilKm = sp.getString("lastOilKm", "0")?.toDoubleOrNull() ?: 0.0
        autoPlay = sp.getBoolean("autoPlay", true)
        fuelBase = sp.getString("fuelBase", "-1")?.toDoubleOrNull() ?: -1.0
        fuelKm = sp.getString("fuelKm", "0")?.toDoubleOrNull() ?: 0.0
        fuelL = sp.getString("fuelL", "0")?.toDoubleOrNull() ?: 0.0
        lastKmL = sp.getString("lastKmL", "0")?.toDoubleOrNull() ?: 0.0
        obdMac = sp.getString("obdMac", "") ?: ""
        obdName = sp.getString("obdName", "") ?: ""
        obdOn = sp.getBoolean("obdOn", true)
        engineL = sp.getString("engineL", "1.6")?.toDoubleOrNull() ?: 1.6
        radios = sp.getString("radios", "") ?: ""
        tankL = sp.getString("tankL", "45")?.toDoubleOrNull() ?: 45.0
        segPct = sp.getString("segPct", "-1")?.toDoubleOrNull() ?: -1.0
        segLow = sp.getString("segLow", "-1")?.toDoubleOrNull() ?: -1.0
        segKm = sp.getString("segKm", "0")?.toDoubleOrNull() ?: 0.0
        ready = true
    }
    fun save() {
        sp.edit().putString("carName", carName).putString("carModel", carModel)
            .putString("carYear", carYear).putInt("themeIdx", themeIdx).putString("ownerName", ownerName).putString("aaPackage", aaPackage).putString("btPackage", btPackage).putBoolean("autoOpen", autoOpen).putString("carPhoto", carPhoto)
            .putInt("oilInterval", oilInterval).putString("lastOilKm", lastOilKm.toString())
            .putBoolean("autoPlay", autoPlay).putString("fuelBase", fuelBase.toString())
            .putString("fuelKm", fuelKm.toString()).putString("fuelL", fuelL.toString())
            .putString("lastKmL", lastKmL.toString()).putString("obdMac", obdMac).putString("obdName", obdName)
            .putBoolean("obdOn", obdOn).putString("engineL", engineL.toString())
            .putString("radios", radios).putString("tankL", tankL.toString()).putString("segPct", segPct.toString())
            .putString("segLow", segLow.toString()).putString("segKm", segKm.toString()).apply()
    }
}

/** Velocidad, posición y kilómetros recorridos (por GPS). */
object Trip {
    var speedKmh by mutableStateOf(0)
    var lat by mutableStateOf<Double?>(null)
    var lon by mutableStateOf<Double?>(null)
    var totalKm by mutableStateOf(0.0)
    var dayKm by mutableStateOf(0.0)
    var monthKm by mutableStateOf(0.0)
    val track = mutableStateListOf<Pair<Double, Double>>()   // recorrido del viaje actual
    private var dayKey = ""
    private var monthKey = ""
    private var last: Location? = null
    private var inited = false

    fun init(ctx: Context) {
        Cfg.init(ctx)
        if (inited) return
        val sp = Cfg.sp
        totalKm = sp.getString("total", "0")?.toDoubleOrNull() ?: 0.0
        dayKey = sp.getString("dayKey", "") ?: ""
        monthKey = sp.getString("monthKey", "") ?: ""
        dayKm = sp.getString("day", "0")?.toDoubleOrNull() ?: 0.0
        monthKm = sp.getString("month", "0")?.toDoubleOrNull() ?: 0.0
        roll()
        inited = true
    }

    private fun roll() {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val m = d.substring(0, 7)
        if (d != dayKey) { dayKey = d; dayKm = 0.0 }
        if (m != monthKey) { monthKey = m; monthKm = 0.0 }
    }

    fun oilRemaining(): Double = Cfg.oilInterval - (totalKm - Cfg.lastOilKm)

    fun onLocation(l: Location) {
        lat = l.latitude; lon = l.longitude
        val kmh = if (l.hasSpeed()) l.speed * 3.6f else 0f
        speedKmh = if (kmh < 3f) 0 else kmh.toInt()
        roll()
        val prev = last
        if (prev != null && l.accuracy <= 40f && kmh >= 3f) {
            val d = prev.distanceTo(l).toDouble()
            val dt = (l.time - prev.time) / 1000.0
            if (d > 1.0 && dt > 0 && d / dt < 70.0) {   // descarta saltos raros del GPS
                val km = d / 1000.0
                totalKm += km; dayKm += km; monthKm += km
            }
        }
        if (l.accuracy <= 40f) {
            val t = track.lastOrNull()
            val r = FloatArray(1)
            if (t != null) Location.distanceBetween(t.first, t.second, l.latitude, l.longitude, r)
            if (t == null || r[0] >= 15f) { track.add(l.latitude to l.longitude); if (track.size > 3000) track.removeAt(0) }
        }
        last = l
        Cfg.sp.edit().putString("total", totalKm.toString()).putString("day", dayKm.toString())
            .putString("month", monthKm.toString()).putString("dayKey", dayKey).putString("monthKey", monthKey).apply()
    }
}

/** Clima con Open-Meteo (gratis, sin llave). */
class Wx(val temp: Int, val max: Int, val min: Int, val rain: Int, val desc: String)

suspend fun fetchWeather(lat: Double, lon: Double): Wx? = withContext(Dispatchers.IO) {
    try {
        val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min," +
            "precipitation_probability_max&timezone=auto&forecast_days=1")
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        val cur = j.getJSONObject("current"); val day = j.getJSONObject("daily")
        Wx(
            Math.round(cur.getDouble("temperature_2m")).toInt(),
            Math.round(day.getJSONArray("temperature_2m_max").getDouble(0)).toInt(),
            Math.round(day.getJSONArray("temperature_2m_min").getDouble(0)).toInt(),
            day.getJSONArray("precipitation_probability_max").optInt(0, 0),
            wxText(cur.getInt("weather_code"))
        )
    } catch (e: Exception) { null }
}

private fun wxText(c: Int) = when (c) {
    0 -> "Despejado"; 1, 2 -> "Poco nublado"; 3 -> "Nublado"; 45, 48 -> "Niebla"
    in 51..57 -> "Llovizna"; in 61..67 -> "Lluvia"; in 71..77 -> "Nieve"
    in 80..82 -> "Chubascos"; in 95..99 -> "Tormenta"; else -> "—"
}

/** Música en reproducción (cualquier app) vía sesiones multimedia. */
class NP(val ok: Boolean, val title: String = "", val artist: String = "",
         val art: Bitmap? = null, val playing: Boolean = false, val c: MediaController? = null,
         val pos: Long = 0L, val dur: Long = 0L)

private fun posOf(c: MediaController): Long {
    val ps = c.playbackState ?: return 0L
    return if (ps.state == PlaybackState.STATE_PLAYING)
        ps.position + ((SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * ps.playbackSpeed).toLong()
    else ps.position
}

fun readNP(ctx: Context): NP = try {
    val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    val list = msm.getActiveSessions(ComponentName(ctx, MediaListener::class.java))
    val c = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
    if (c == null) NP(true) else {
        val m = c.metadata
        NP(true, m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "",
            m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "",
            m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART),
            c.playbackState?.state == PlaybackState.STATE_PLAYING, c, posOf(c),
            m?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L)
    }
} catch (e: SecurityException) { NP(false) } catch (e: Exception) { NP(true) }
