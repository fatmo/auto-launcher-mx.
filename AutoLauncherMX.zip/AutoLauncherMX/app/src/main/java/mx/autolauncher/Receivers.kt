package mx.autolauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent

/** Al conectar el Bluetooth del teléfono o al encender el equipo, manda "Play". */
class AutoPlayReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Cfg.init(ctx)
        if (!Cfg.autoPlay) return
        // No arrancar música cuando lo que se conecta es el adaptador OBD2
        if (intent.action == "android.bluetooth.device.action.ACL_CONNECTED") {
            try {
                val d = intent.getParcelableExtra<android.bluetooth.BluetoothDevice>("android.bluetooth.device.extra.DEVICE")
                val n = (d?.name ?: "").uppercase()
                if (d != null && (d.address == Cfg.obdMac || n.contains("OBD") || n.contains("ELM") || n.contains("VLINK") || n.contains("VGATE"))) return
            } catch (e: Exception) {}
        }
        val wait = if (intent.action == Intent.ACTION_BOOT_COMPLETED) 6000L else 3000L
        val pr = goAsync()
        Handler(Looper.getMainLooper()).postDelayed({
            try { Actions.mediaKey(ctx.applicationContext, KeyEvent.KEYCODE_MEDIA_PLAY) } finally { pr.finish() }
        }, wait)
    }
}
