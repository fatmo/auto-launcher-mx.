package mx.autolauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import androidx.core.content.ContextCompat

/**
 * Al encender el equipo: arranca el GPS/OBD, abre el launcher y reanuda la música.
 * Al conectar un Bluetooth: manda "Play" (ignora el adaptador OBD2).
 */
class AutoPlayReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Cfg.init(ctx)
        val app = ctx.applicationContext
        val a = intent.action
        val boot = a == Intent.ACTION_BOOT_COMPLETED || a == "android.intent.action.QUICKBOOT_POWERON" ||
            a == "com.htc.intent.action.QUICKBOOT_POWER_ON"
        var play = Cfg.autoPlay
        if (a == "android.bluetooth.device.action.ACL_CONNECTED" && play) {
            try {
                val d = intent.getParcelableExtra<android.bluetooth.BluetoothDevice>("android.bluetooth.device.extra.DEVICE")
                val n = (d?.name ?: "").uppercase()
                if (d != null && (d.address == Cfg.obdMac || n.contains("OBD") || n.contains("ELM") || n.contains("VLINK") || n.contains("VGATE"))) play = false
            } catch (e: Exception) {}
        }
        if (boot) {
            try { ContextCompat.startForegroundService(app, Intent(app, TripService::class.java)) } catch (e: Exception) {}
        }
        val open = boot && Cfg.autoOpen
        if (!play && !open) return
        val pr = goAsync()
        val h = Handler(Looper.getMainLooper())
        if (open) h.postDelayed({
            // Android 9 permite abrir pantallas desde segundo plano; así le ganamos al launcher de fábrica
            try { app.startActivity(Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)) } catch (e: Exception) {}
        }, 4500L)
        h.postDelayed({
            try { if (play) Actions.mediaKey(app, KeyEvent.KEYCODE_MEDIA_PLAY) } finally { pr.finish() }
        }, if (boot) 7000L else 3000L)
    }
}
