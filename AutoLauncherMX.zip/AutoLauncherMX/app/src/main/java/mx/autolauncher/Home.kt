package mx.autolauncher

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.Navigation
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Radio
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private class DockItem(val label: String, val icon: ImageVector, val onClick: () -> Unit)

@Composable
fun Home(u: Dp, aspect: Float, go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    var wx by remember { mutableStateOf<Wx?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            val la = Trip.lat; val lo = Trip.lon
            if (la != null && lo != null) { fetchWeather(la, lo)?.let { wx = it }; delay(30 * 60_000L) }
            else delay(5_000L)
        }
    }
    val pick = rememberPhotoPicker()
    val items = listOf(
        DockItem("Radio", Icons.Rounded.Radio) { go(Screen.RADIO) },
        DockItem("Música", Icons.Rounded.MusicNote) { Actions.music(ctx) },
        DockItem("Teléfono", Icons.Rounded.Phone) { Actions.phone(ctx) },
        DockItem("Bluetooth", Icons.Rounded.Bluetooth) { Actions.bluetooth(ctx) },
        DockItem("YouTube", Icons.Rounded.PlayCircle) { go(Screen.YOUTUBE) },
        DockItem("Cámara", Icons.Rounded.CameraAlt) { Actions.camera(ctx) },
        DockItem("Ajustes", Icons.Rounded.Settings) { Actions.settings(ctx) },
        DockItem("Apps", Icons.Rounded.Apps) { go(Screen.APPS) },
    )

    if (aspect >= 1.4f) {
        Column(Modifier.fillMaxSize().padding(horizontal = u * 2.2f, vertical = u * 1.4f), verticalArrangement = Arrangement.spacedBy(u * 1.6f)) {
            TopBar(u, wx, false) { go(Screen.SETTINGS) }
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(u * 2)) {
                Column(Modifier.weight(0.29f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(u * 2)) {
                    VehicleCard(u, Modifier.weight(1.55f).fillMaxWidth(), pick)
                    SpeedCard(u, Modifier.weight(1f).fillMaxWidth())
                }
                MapCard(u, Modifier.weight(0.44f).fillMaxHeight(), go)
                AudioCard(u, Modifier.weight(0.27f).fillMaxHeight())
            }
            Row(Modifier.fillMaxWidth().height(u * 20), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                items.forEach { DockCircle(u, it) }
            }
        }
    } else {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(u * 2), verticalArrangement = Arrangement.spacedBy(u * 2)) {
            TopBar(u, wx, true) { go(Screen.SETTINGS) }
            VehicleCard(u, Modifier.fillMaxWidth().height(u * 40), pick)
            SpeedCard(u, Modifier.fillMaxWidth().height(u * 26))
            MapCard(u, Modifier.fillMaxWidth().height(u * 46), go)
            AudioCard(u, Modifier.fillMaxWidth().height(u * 56))
            items.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth()) { row.forEach { Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { DockCircle(u, it) } } }
            }
        }
    }
}

@Composable
private fun DockCircle(u: Dp, it: DockItem) {
    val size = maxOf(56.dp, u * 11)
    Column(Modifier.clip(RoundedCornerShape(u * 2)).clickable(onClick = it.onClick).padding(u * 0.8f),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(u * 0.8f)) {
        Box(Modifier.size(size).clip(CircleShape).background(Mx.Panel).border(1.dp, Mx.Line, CircleShape), contentAlignment = Alignment.Center) {
            Icon(it.icon, it.label, tint = Mx.Text, modifier = Modifier.size(u * 5))
        }
        Txt(it.label, u, 2.8f, Mx.Text)
    }
}

@Composable
private fun TopBar(u: Dp, wx: Wx?, compact: Boolean, onSettings: () -> Unit) {
    val now by produceState(Date()) { while (true) { value = Date(); delay(5_000) } }
    val time = SimpleDateFormat("h:mm a", Locale.getDefault()).format(now)
    val date = SimpleDateFormat("EEEE, d 'de' MMMM", Locale.getDefault()).format(now).replaceFirstChar { it.uppercase() }
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val hi = (if (h < 12) "Buenos días" else if (h < 19) "Buenas tardes" else "Buenas noches") +
        (if (Cfg.ownerName.isBlank()) "" else ", ${Cfg.ownerName}")
    Row(Modifier.fillMaxWidth().height(u * 9), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(u * 2)) {
        Row(Modifier.weight(1f), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(u * 1.6f)) {
            Txt(time, u, 6.4f, bold = true)
            if (!compact) Txt(date, u, 2.8f, Mx.Mute)
        }
        if (!compact) {
            Icon(Icons.Rounded.Cloud, null, tint = Mx.Text, modifier = Modifier.size(u * 4))
            Column {
                Txt(if (wx != null) "${wx.temp}°C  ${wx.desc}" else "Clima…", u, 3f, bold = true)
                if (wx != null) Txt("Máx ${wx.max}° · Mín ${wx.min}° · Lluvia ${wx.rain}%", u, 2f, if (wx.rain >= 50) Mx.Blue2 else Mx.Mute)
            }
            Txt(hi, u, 3.4f)
        } else if (wx != null) Txt("${wx.temp}°C", u, 3f, bold = true)
        CircleBtn(maxOf(48.dp, u * 8), Mx.Panel2, onSettings) { Icon(Icons.Rounded.Settings, "Ajustes del launcher", tint = Mx.Text, modifier = Modifier.size(u * 4)) }
    }
}

// ───────────────────────── Vehículo ─────────────────────────

@Composable
fun rememberPhotoPicker(): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
            Cfg.carPhoto = uri.toString(); Cfg.save()
        }
    }
    return {
        try { launcher.launch(arrayOf("image/*")) }
        catch (e: Exception) { Toast.makeText(ctx, "Esta pantalla no tiene selector de fotos", Toast.LENGTH_LONG).show() }
    }
}

private fun loadPhoto(ctx: Context, uri: String): ImageBitmap? = try {
    val u = Uri.parse(uri)
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (o.outWidth / s > 1400) s *= 2
    ctx.contentResolver.openInputStream(u)?.use {
        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
    }?.asImageBitmap()
} catch (e: Exception) { null }

@Composable
private fun VehicleCard(u: Dp, modifier: Modifier, pick: () -> Unit) {
    val ctx = LocalContext.current
    val photo by produceState<ImageBitmap?>(null, Cfg.carPhoto) {
        value = if (Cfg.carPhoto.isEmpty()) null else withContext(Dispatchers.IO) { loadPhoto(ctx, Cfg.carPhoto) }
    }
    MxCard(u, modifier) {
        Txt(Cfg.carName, u, 4.6f, bold = true)
        Spacer(Modifier.height(u * 0.8f))
        Box(Modifier.clip(RoundedCornerShape(u * 1.4f)).background(Mx.Blue).padding(horizontal = u * 1.6f, vertical = u * 0.5f)) {
            Txt(if (Cfg.carYear.isBlank()) Cfg.carModel else Cfg.carYear, u, 2.4f, Mx.OnAccent, bold = true)
        }
        Spacer(Modifier.height(u * 1.4f))
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(u * 2f)).background(Mx.Panel2).clickable(onClick = pick),
            contentAlignment = Alignment.Center) {
            val img = photo
            if (img != null) Image(img, Cfg.carName, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else {
                Image(ImageBitmap.imageResource(R.drawable.aveo_default), Cfg.carName,
                    Modifier.fillMaxSize().padding(horizontal = u * 1.2f, vertical = u * 1.6f), contentScale = ContentScale.Fit)
            }
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = u * 0.8f)) { Txt("Toca para cambiar la foto", u, 1.8f, Mx.Mute) }
        }
    }
}

/** Chevrolet Aveo sedán gris (dibujo propio en vector; se reemplaza con tu foto al tocar). */
@Composable
fun AveoArt(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = minOf(size.width / 400f, size.height / 150f)
        val ox = (size.width - 400f * s) / 2f
        val oy = (size.height - 150f * s) / 2f
        fun p(x: Float, y: Float) = Offset(ox + x * s, oy + y * s)
        fun Path.m(x: Float, y: Float) = moveTo(p(x, y).x, p(x, y).y)
        fun Path.l(x: Float, y: Float) = lineTo(p(x, y).x, p(x, y).y)
        fun Path.c(a: Float, b: Float, c: Float, d: Float, e: Float, f: Float) =
            cubicTo(p(a, b).x, p(a, b).y, p(c, d).x, p(c, d).y, p(e, f).x, p(e, f).y)

        drawOval(Color(0x66000000), topLeft = p(28f, 122f), size = Size(344f * s, 16f * s))
        val body = Path().apply {
            m(16f, 104f); c(12f, 96f, 14f, 86f, 26f, 82f); l(40f, 80f)
            c(70f, 74f, 100f, 70f, 124f, 66f); c(140f, 54f, 156f, 42f, 176f, 37f); l(246f, 35f)
            c(266f, 36f, 284f, 48f, 298f, 62f); c(330f, 64f, 360f, 66f, 378f, 72f)
            c(386f, 76f, 388f, 88f, 384f, 104f); l(16f, 104f); close()
        }
        drawPath(body, Brush.verticalGradient(listOf(Color(0xFFB4BBC5), Color(0xFF6A717C)), startY = oy + 35f * s, endY = oy + 104f * s))
        // vidrios
        val glass = Path().apply { m(130f, 64f); c(143f, 54f, 158f, 44f, 177f, 40f); l(243f, 38f); c(260f, 39f, 276f, 50f, 288f, 62f); close() }
        drawPath(glass, Color(0xFF1B2A3D))
        drawLine(Color(0xFF8E959F), p(208f, 39f), p(208f, 64f), strokeWidth = 5f * s)
        // puertas y manijas
        for (x in listOf(134f, 208f, 292f)) drawLine(Color(0x66000000), p(x, 66f), p(x, 102f), strokeWidth = 1.5f * s)
        drawLine(Color(0x88000000), p(180f, 74f), p(194f, 74f), strokeWidth = 2.2f * s)
        drawLine(Color(0x88000000), p(256f, 74f), p(270f, 74f), strokeWidth = 2.2f * s)
        // detalle azul de la marca
        drawLine(Mx.Blue, p(42f, 92f), p(368f, 92f), strokeWidth = 1.6f * s)
        // luces
        drawPath(Path().apply { m(24f, 84f); l(46f, 80f); l(44f, 88f); l(24f, 90f); close() }, Color(0xFFD5E8FF))
        drawPath(Path().apply { m(374f, 72f); l(385f, 77f); l(385f, 87f); l(376f, 85f); close() }, Color(0xFFE23B3B))
        // llantas
        for (cx in listOf(92f, 312f)) {
            clipRect(top = 0f, bottom = oy + 104f * s) { drawCircle(Color(0xFF0B0D10), 29f * s, p(cx, 104f)) }
            drawCircle(Color(0xFF111418), 23f * s, p(cx, 106f))
            drawCircle(Color(0xFFC3C9D1), 13f * s, p(cx, 106f))
            drawCircle(Color(0xFF6B727C), 4f * s, p(cx, 106f))
        }
    }
}

@Composable
private fun SpeedCard(u: Dp, modifier: Modifier) = MxCard(u, modifier) {
    val spd = if (Obd.connected) (Obd.speed ?: Trip.speedKmh) else Trip.speedKmh
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Txt("Velocidad", u, 2.8f, Mx.Mute)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(u * 0.8f)) {
            Box(Modifier.size(u * 1.4f).clip(CircleShape).background(if (Trip.lat != null || Obd.connected) Color(0xFF3DDC84) else Amber))
            Txt(if (Obd.connected) "OBD" else "GPS", u, 2.2f, Mx.Mute)
        }
    }
    Spacer(Modifier.weight(1f))
    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(u)) {
        Txt(spd.toString(), u, 13f, bold = true)
        Txt("km/h", u, 3.2f, Mx.Mute)
    }
    if (Obd.connected) Txt("${Obd.rpm ?: "–"} rpm · ${Obd.coolant ?: "–"}°C · ${Obd.volts?.let { "%.1f".format(it) } ?: "–"} V", u, 2.2f, Mx.Mute)
}

// ───────────────────────── Mapa ─────────────────────────

@Composable
private fun MapCard(u: Dp, modifier: Modifier, go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val follow = remember { mutableStateOf(true) }
    val shape = RoundedCornerShape(u * 2.8f)
    val chips = buildList<Pair<String, Color>> {
        add("Hoy ${"%.1f".format(Trip.dayKm)} km · Mes ${"%.0f".format(Trip.monthKm)} km" to Mx.Text)
        val left = Trip.oilRemaining()
        add((if (left <= 0) "Aceite: cambio vencido" else "Aceite en ${"%.0f".format(left)} km") to (if (left <= 500) Amber else Mx.Mute))
        if (Obd.connected) {
            val now = Obd.instKmL
            if (now != null) add("Ahora ${"%.1f".format(now)} km/L" to Mx.Blue2)
            else Obd.lph?.let { add("Ralentí ${"%.1f".format(it)} L/h" to Mx.Blue2) }
            Obd.fuelPct?.let { p ->
                val liters = p * Cfg.tankL / 100.0
                val kmL = if (Cfg.avgKmL > 0) Cfg.avgKmL else (Obd.tripKmL ?: 0.0)
                val range = if (kmL > 0) " · ~${"%.0f".format(liters * kmL)} km" else ""
                add((if (p <= 15) "¡Reserva! ${"%.0f".format(liters)} L$range" else "Gasolina $p% · ${"%.0f".format(liters)} L$range") to (if (p <= 15) Amber else Mx.Mute))
            }
        } else if (Cfg.lastKmL > 0) add("${"%.1f".format(Cfg.lastKmL)} km/L (prom ${"%.1f".format(Cfg.avgKmL)})" to Mx.Blue2)
    }
    Box(modifier.clip(shape).background(Mx.Panel).border(1.dp, Mx.Line, shape)) {
        LiveMap(u, Modifier.fillMaxSize(), follow, false)
        Box(Modifier.fillMaxSize().clickable { go(Screen.MAP) })
        Row(Modifier.align(Alignment.TopStart).padding(u * 2).clip(RoundedCornerShape(u * 2)).background(Color(0xCC050607))
            .padding(horizontal = u * 1.6f, vertical = u * 0.9f), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(u)) {
            Icon(Icons.Rounded.MyLocation, null, tint = Mx.Text, modifier = Modifier.size(u * 3))
            Txt("Mapa en vivo", u, 2.8f)
        }
        Column(Modifier.align(Alignment.TopEnd).padding(u * 2), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(u * 0.8f)) {
            chips.forEach { (t, c) ->
                Box(Modifier.clip(RoundedCornerShape(u * 1.6f)).background(Color(0xCC050607)).padding(horizontal = u * 1.3f, vertical = u * 0.6f)) {
                    Txt(t, u, 2.2f, c)
                }
            }
        }
        Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(u * 2), horizontalArrangement = Arrangement.spacedBy(u * 1.6f)) {
            MapAction(u, "Waze", "Navegar", true, Modifier.weight(1f)) { Actions.waze(ctx) }
            MapAction(u, "Google Maps", "Navegar", false, Modifier.weight(1f)) { Actions.gmaps(ctx) }
        }
    }
}

@Composable
private fun MapAction(u: Dp, title: String, sub: String, filled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Row(modifier.height(maxOf(56.dp, u * 12)).clip(RoundedCornerShape(u * 2.2f)).background(if (filled) Mx.Blue else Mx.Panel2)
        .clickable(onClick = onClick).padding(horizontal = u * 1.8f), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(u * 1.4f)) {
        Icon(Icons.Rounded.Navigation, null, tint = if (filled) Mx.OnAccent else Mx.Blue2, modifier = Modifier.size(u * 4.4f))
        Column {
            Txt(title, u, 3.2f, if (filled) Mx.OnAccent else Mx.Text, bold = true)
            Txt(sub, u, 2.2f, if (filled) Mx.OnAccent.copy(alpha = 0.75f) else Mx.Mute)
        }
    }
}

// ───────────────────────── Audio ─────────────────────────

private fun mmss(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return "%d:%02d".format(s / 60, s % 60) }

@Composable
private fun AudioCard(u: Dp, modifier: Modifier) {
    val ctx = LocalContext.current
    val np by produceState(NP(true)) { while (true) { value = readNP(ctx); delay(1000) } }
    val tc = np.c?.transportControls
    MxCard(u, modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Txt("AUDIO", u, 2.2f, Mx.Mute)
            Txt(if (Radio.current != null) "RADIO" else if (np.c != null) "REPRODUCIENDO" else "", u, 2.2f, Mx.Blue, bold = true)
        }
        if (!np.ok) {
            Spacer(Modifier.weight(1f))
            Text("Para ver la carátula y controlar la música, activa el acceso a notificaciones.", color = Mx.Mute, fontSize = (u.value * 2.4f).sp)
            Spacer(Modifier.height(u * 1.5f))
            DockButton("Activar acceso", u, Modifier.fillMaxWidth()) {
                Actions.launch(ctx, android.content.Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            Spacer(Modifier.weight(1f))
        } else {
            val art = remember(np.art) { np.art?.asImageBitmap() }
            val progress = if (np.dur > 0) (np.pos.toFloat() / np.dur).coerceIn(0f, 1f) else 0f
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(Modifier.fillMaxHeight().aspectRatio(1f).padding(u * 0.6f), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        val w = u.toPx() * 0.8f
                        val tl = Offset(w / 2, w / 2); val sz = Size(size.width - w, size.height - w)
                        drawArc(Mx.Panel2, 0f, 360f, false, tl, sz, style = Stroke(w))
                        if (progress > 0f) drawArc(Mx.Blue, -90f, 360f * progress, false, tl, sz, style = Stroke(w, cap = StrokeCap.Round))
                    }
                    Box(Modifier.fillMaxSize().padding(u * 2.2f).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Mx.Blue2, Mx.Blue))), contentAlignment = Alignment.Center) {
                        if (art != null) Image(art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        else Icon(Icons.Rounded.MusicNote, null, tint = Mx.OnAccent, modifier = Modifier.size(u * 9))
                    }
                }
            }
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Txt(np.title.ifEmpty { "Sin música" }, u, 3.6f, bold = true)
                Txt(np.artist, u, 2.6f, Mx.Mute)
                Txt(if (np.dur > 0) "${mmss(np.pos)} / ${mmss(np.dur)}" else if (Radio.current != null) "En vivo" else "", u, 2.2f, Mx.Mute)
            }
            Spacer(Modifier.height(u * 1.2f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                CircleBtn(maxOf(48.dp, u * 8), Mx.Panel2, { tc?.skipToPrevious() ?: Actions.mediaKey(ctx, android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS) }) {
                    Icon(Icons.Rounded.SkipPrevious, "Anterior", tint = Mx.Text, modifier = Modifier.size(u * 4.4f)) }
                CircleBtn(maxOf(60.dp, u * 10.5f), Mx.Blue, {
                    if (tc != null) { if (np.playing) tc.pause() else tc.play() }
                    else Actions.mediaKey(ctx, android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                }) { Icon(if (np.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play/Pausa", tint = Mx.OnAccent, modifier = Modifier.size(u * 6)) }
                CircleBtn(maxOf(48.dp, u * 8), Mx.Panel2, { tc?.skipToNext() ?: Actions.mediaKey(ctx, android.view.KeyEvent.KEYCODE_MEDIA_NEXT) }) {
                    Icon(Icons.Rounded.SkipNext, "Siguiente", tint = Mx.Text, modifier = Modifier.size(u * 4.4f)) }
            }
        }
    }
}
