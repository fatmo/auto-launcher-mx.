package mx.autolauncher

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

class Accent(val name: String, val main: Color, val light: Color, val on: Color)

val Accents = listOf(
    Accent("Rojo", Color(0xFFFF3B30), Color(0xFFFF7A70), Color.White),
    Accent("Amarillo", Color(0xFFFFC400), Color(0xFFFFDB4D), Color.Black),
    Accent("Verde", Color(0xFF2ECC71), Color(0xFF6FE39B), Color.Black),
    Accent("Azul", Color(0xFF2D7BFF), Color(0xFF5AA0FF), Color.White),
)

object Mx {
    val Bg = Color(0xFF050607)
    val Panel = Color(0xFF15181D)
    val Panel2 = Color(0xFF1E2229)
    val Line = Color(0xFF2A2F38)
    // "Blue" y "Blue2" son el color de acento del tema elegido (rojo, amarillo, verde o azul)
    val Blue: Color get() = Accents[Cfg.themeIdx.coerceIn(0, Accents.size - 1)].main
    val Blue2: Color get() = Accents[Cfg.themeIdx.coerceIn(0, Accents.size - 1)].light
    val OnAccent: Color get() = Accents[Cfg.themeIdx.coerceIn(0, Accents.size - 1)].on
    val Text = Color(0xFFEEF2F7)
    val Mute = Color(0xFF8B94A3)
    // Para la tipografía tecnológica: agrega Orbitron/Rajdhani en res/font y cámbiala aquí.
    val Tech: FontFamily = FontFamily.Monospace
}

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(background = Mx.Bg, surface = Mx.Panel, primary = Mx.Blue, onSurface = Mx.Text),
        content = content
    )
}
