package mx.autolauncher

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.provider.MediaStore
import android.provider.Settings
import android.net.Uri
import android.view.KeyEvent
import android.widget.Toast

object Actions {
    fun launch(ctx: Context, intent: Intent) {
        try { ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(ctx, "App no disponible", Toast.LENGTH_SHORT).show() }
    }
    fun navigation(ctx: Context) = launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")))
    fun waze(ctx: Context) = launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("waze://")))
    fun gmaps(ctx: Context) = launch(ctx,
        ctx.packageManager.getLaunchIntentForPackage("com.google.android.apps.maps")
            ?: Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")))
    fun bluetooth(ctx: Context) = launch(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    fun music(ctx: Context) = launch(ctx, Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC))
    fun phone(ctx: Context) = launch(ctx, Intent(Intent.ACTION_DIAL))
    fun camera(ctx: Context) = launch(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
    fun settings(ctx: Context) = launch(ctx, Intent(Settings.ACTION_SETTINGS))
    fun display(ctx: Context) = launch(ctx, Intent(Settings.ACTION_DISPLAY_SETTINGS))

    private fun audio(ctx: Context) = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    fun mediaKey(ctx: Context, code: Int) {
        val am = audio(ctx)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
    fun volume(ctx: Context, dir: Int) =
        audio(ctx).adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
}
