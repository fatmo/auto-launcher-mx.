package mx.autolauncher

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.provider.MediaStore
import android.provider.Settings
import android.net.Uri
import android.view.KeyEvent
import android.widget.Toast

object Actions {
    fun launch(ctx: Context, intent: Intent) {
        try { ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(ctx, "App no disponible", Toast.LENGTH_SHORT).show() }
    }
    fun navigation(ctx: Context) = launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")))
    fun waze(ctx: Context) = launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("waze://")))
    fun gmaps(ctx: Context) = launch(ctx,
        ctx.packageManager.getLaunchIntentForPackage("com.google.android.apps.maps")
            ?: Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")))
    // ── Android Auto (mediante una app receptora tipo Headunit Reloaded) ──
    private val AA_APPS = listOf("gb.xxy.hr", "gb.xxy.trial")

    /** Paquete de la app receptora instalada (Open Headunit, Headunit Reloaded u otra), o null. */
    fun aaInstalled(ctx: Context): String? {
        val pm = ctx.packageManager
        (listOf(Cfg.aaPackage.trim()).filter { it.isNotEmpty() } + AA_APPS)
            .firstOrNull { pm.getLaunchIntentForPackage(it) != null }?.let { return it }
        // Respaldo: cualquier app instalada cuyo nombre contenga "headunit"
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(q, 0)
            .firstOrNull { it.loadLabel(pm).toString().contains("headunit", ignoreCase = true) }
            ?.activityInfo?.packageName
    }

    fun androidAuto(ctx: Context) {
        val pkg = aaInstalled(ctx)
        val i = pkg?.let { ctx.packageManager.getLaunchIntentForPackage(it) }
        if (i != null) launch(ctx, i)
        else Toast.makeText(ctx, "Instala una app de Android Auto (ver Ajustes del launcher)", Toast.LENGTH_LONG).show()
    }

    /** Abre la página de Open Headunit (gratis, código abierto) para descargar el APK. */
    fun getAndroidAuto(ctx: Context) =
        launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/andreknieriem/headunit-revived")))

    /** Abre la app de Bluetooth de la pantalla (si la elegiste); si no, los ajustes de Bluetooth de Android. */
    fun bluetooth(ctx: Context) {
        val pm = ctx.packageManager
        var p = Cfg.btPackage.trim()
        if (p.isEmpty()) {
            // Autodetección: app con nombre tipo "Música Bluetooth" / "BT Music"
            val re = Regex("(m[uú]sica|music).*(bluetooth|bt)|(bluetooth|bt).*(m[uú]sica|music)", RegexOption.IGNORE_CASE)
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            p = pm.queryIntentActivities(q, 0).firstOrNull { re.containsMatchIn(it.loadLabel(pm).toString()) }
                ?.activityInfo?.packageName ?: ""
        }
        val i = if (p.isNotEmpty()) pm.getLaunchIntentForPackage(p) else null
        if (i != null) launch(ctx, i) else launch(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    }
    fun homeSettings(ctx: Context) = launch(ctx, Intent("android.settings.HOME_SETTINGS"))
    fun batterySettings(ctx: Context) = launch(ctx, Intent("android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS"))
    fun music(ctx: Context) = launch(ctx, Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC))
    fun phone(ctx: Context) = launch(ctx, Intent(Intent.ACTION_DIAL))
    fun camera(ctx: Context) = launch(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
    fun settings(ctx: Context) = launch(ctx, Intent(Settings.ACTION_SETTINGS))
    fun display(ctx: Context) = launch(ctx, Intent(Settings.ACTION_DISPLAY_SETTINGS))

    private fun audio(ctx: Context) = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    fun mediaKey(ctx: Context, code: Int) {
        val am = audio(ctx)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
    fun volume(ctx: Context, dir: Int) =
        audio(ctx).adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
}
